import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function FrostAndToastPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white px-6 py-10 space-y-16">
      <motion.section 
        className="text-center max-w-4xl mx-auto"
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 1 }}>
        <h1 className="text-5xl font-bold leading-tight mb-6">
          Revoluciona la experiencia laboral con <span className="text-indigo-400">Frost & Toast</span>
        </h1>
        <p className="text-lg text-gray-300">
          El ecosistema inteligente de cafetería y comedor para empresas que conecta a tus empleados con la mejor experiencia de alimentación, tecnología y bienestar.
        </p>
        <div className="mt-8">
          <Button className="text-lg px-8 py-4 bg-indigo-500 hover:bg-indigo-600">Solicitar Demostración</Button>
        </div>
      </motion.section>
    </div>
  );
}
